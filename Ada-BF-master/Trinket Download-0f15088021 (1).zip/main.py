#
# Paste the data you wish to graph in tab-delimited rows in the format:
#
#       xdata <tab> ydata
#
# In this example the xdata is time (s) and y data is y position (cm)
#

input1 = []
f = open("input.txt", "r")
for x in f:
  input1.append([float(elem) for elem in x.rstrip("\n").split(" ")])
  
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import random

print(input1)
plt.figure(figsize=(10,6))
col = ['b', 'g', 'r', 'k']
sizes = list(range(150000,550000,50000))
i = 0
for idx in range(3):
  plt.plot(sizes, [elem[0] for elem in input1[idx * 8: (idx + 1) * 8]], linestyle = "solid", marker = "x")

plt.legend(["BF", "LBF", "Ada_BF"])

plt.title("False Positive Rate vs Bitmap Size")
plt.xlabel("Bitmap Size")
plt.ylabel("False Positive Rate")
plt.show()

